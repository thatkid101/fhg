﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

class GDI_Effects
{
    // DLL Imports for screen access and GDI operations
    [DllImport("user32.dll")]
    private static extern IntPtr GetDC(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateCompatibleDC(IntPtr hdc);

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateBitmap(int width, int height, int planes, int bitsPerPixel, IntPtr data);

    [DllImport("gdi32.dll")]
    private static extern bool SelectObject(IntPtr hdc, IntPtr hgdiobj);

    [DllImport("gdi32.dll")]
    private static extern bool BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, uint dwRop);

    [DllImport("gdi32.dll")]
    private static extern bool GetBitmapBits(IntPtr hBitmap, int dwCount, IntPtr lpBits);

    [DllImport("gdi32.dll")]
    private static extern bool SetBitmapBits(IntPtr hBitmap, int dwCount, IntPtr lpBits);

    [DllImport("kernel32.dll")]
    private static extern IntPtr VirtualAlloc(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

    [DllImport("kernel32.dll")]
    private static extern bool VirtualFree(IntPtr lpAddress, uint dwSize, uint dwFreeType);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr hObject);

    [DllImport("user32.dll")]
    public static extern int GetSystemMetrics(int nIndex);

    private const int SM_CXSCREEN = 0;
    private const int SM_CYSCREEN = 1;
    private const uint SRCCOPY = 0x00CC0020;

    static void Main()
    {
        // Ask the user if they want to run the GDI effects
        DialogResult result = MessageBox.Show("Run Malware?", "WHATTHEFU-.exe by thatkid101", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (result == DialogResult.Yes)
        {
            // Ask if they are sure about running the GDI effects
            result = MessageBox.Show("Are you sure", "WHATTHEFU-.exe by thatkid101", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                // Run each effect for 15 seconds
                RunFlashingScreenEffect();
                RunShaderEffect();
                RunBouncingBallEffect();
                RunWaveDistortionEffect();
                RunRotatingCubeEffect();
                RunCircularRippleEffect();
                RunInvertGDI();
                RunBouncingMessage();
            }
            else
            {
                MessageBox.Show("Just remember you took a good option.", "Fax", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        else
        {
            MessageBox.Show("Just remember you took a good option.", "Fax", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    // Effect 1: Flashing Screen
    private static void RunFlashingScreenEffect()
    {
        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);
        IntPtr desk = GetDC(IntPtr.Zero);

        DateTime startTime = DateTime.Now;
        Random rand = new Random();

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                Color randomColor = Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256));
                g.Clear(randomColor);
            }

            Thread.Sleep(100); // Flash every 100 ms
        }

        ReleaseDC(IntPtr.Zero, desk);
    }

    // Effect 2: Shader Effect
    private static void RunShaderEffect()
    {
        int width = GetSystemMetrics(SM_CXSCREEN);
        int height = GetSystemMetrics(SM_CYSCREEN);

        IntPtr desk = GetDC(IntPtr.Zero);
        DateTime startTime = DateTime.Now;

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                for (int y = 0; y < height; y += 5)
                {
                    for (int x = 0; x < width; x += 5)
                    {
                        int colorValue = (x ^ y) & 0xFF;
                        g.FillRectangle(new SolidBrush(Color.FromArgb(colorValue, colorValue, colorValue)), x, y, 5, 5);
                    }
                }
            }
        }

        ReleaseDC(IntPtr.Zero, desk);
    }

    // Effect 3: Bouncing Ball
    private static void RunBouncingBallEffect()
    {
        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);

        int ballSize = 50;
        int ballX = screenWidth / 2;
        int ballY = screenHeight / 2;
        int velocityX = 5;
        int velocityY = 5;

        IntPtr desk = GetDC(IntPtr.Zero);
        Random rand = new Random();
        DateTime startTime = DateTime.Now;

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                // Clear the previous ball
                g.FillRectangle(new SolidBrush(Color.Black), ballX, ballY, ballSize, ballSize);

                // Update ball position
                ballX += velocityX;
                ballY += velocityY;

                // Bounce off edges
                if (ballX <= 0 || ballX + ballSize >= screenWidth) velocityX = -velocityX;
                if (ballY <= 0 || ballY + ballSize >= screenHeight) velocityY = -velocityY;

                // Draw the ball
                Color ballColor = Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256));
                g.FillEllipse(new SolidBrush(ballColor), ballX, ballY, ballSize, ballSize);
            }

            Thread.Sleep(16); // ~60 FPS
        }

        ReleaseDC(IntPtr.Zero, desk);
    }

    // Effect 4: Wave Distortion
    private static void RunWaveDistortionEffect()
    {
        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);
        IntPtr desk = GetDC(IntPtr.Zero);

        DateTime startTime = DateTime.Now;
        double frequency = 0.05; // Frequency of the wave

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                for (int y = 0; y < screenHeight; y += 5)
                {
                    int offsetX = (int)(Math.Sin((y + (DateTime.Now.Millisecond / 10.0)) * frequency) * 20);
                    g.CopyFromScreen(offsetX, y, 0, y, new Size(screenWidth, 5));
                }
            }

            Thread.Sleep(50); // Update every 50 ms
        }

        ReleaseDC(IntPtr.Zero, desk);
    }

    // Effect 5: Rotating Cube
    private static void RunRotatingCubeEffect()
    {
        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);

        IntPtr desk = GetDC(IntPtr.Zero);
        DateTime startTime = DateTime.Now;

        PointF[] cubeVertices = new PointF[8];
        int cubeSize = 100;
        float angle = 0;

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                g.Clear(Color.Black);

                // Rotate and project cube vertices
                for (int i = 0; i < 8; i++)
                {
                    float x = (i & 1) == 0 ? -1 : 1;
                    float y = (i & 2) == 0 ? -1 : 1;
                    float z = (i & 4) == 0 ? -1 : 1;

                    float rotX = x * (float)Math.Cos(angle) - z * (float)Math.Sin(angle);
                    float rotZ = x * (float)Math.Sin(angle) + z * (float)Math.Cos(angle);

                    cubeVertices[i] = new PointF(
                        screenWidth / 2 + rotX * cubeSize,
                        screenHeight / 2 + y * cubeSize - rotZ * 30
                    );
                }

                // Draw cube edges
                for (int i = 0; i < 4; i++)
                {
                    g.DrawLine(Pens.White, cubeVertices[i], cubeVertices[(i + 1) % 4]);
                    g.DrawLine(Pens.White, cubeVertices[i + 4], cubeVertices[((i + 1) % 4) + 4]);
                    g.DrawLine(Pens.White, cubeVertices[i], cubeVertices[i + 4]);
                }
            }

            angle += 0.05f; // Increase rotation angle
            Thread.Sleep(16); // ~60 FPS
        }

        ReleaseDC(IntPtr.Zero, desk);
    }

    // Effect 6: Circular Ripple
    private static void RunCircularRippleEffect()
    {
        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);
        IntPtr desk = GetDC(IntPtr.Zero);

        DateTime startTime = DateTime.Now;
        Random rand = new Random();

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                int centerX = screenWidth / 2;
                int centerY = screenHeight / 2;

                int radius = rand.Next(50, 200);
                g.FillEllipse(new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256))), centerX - radius, centerY - radius, radius * 2, radius * 2);
            }

            Thread.Sleep(50); // Update every 50 ms
        }

        ReleaseDC(IntPtr.Zero, desk);
    }

    // Effect 7: Invert GDI Effect
    private static void RunInvertGDI()
    {
        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);
        IntPtr desk = GetDC(IntPtr.Zero);

        DateTime startTime = DateTime.Now;

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                // Invert colors on the screen using a ColorMatrix
                ColorMatrix invertMatrix = new ColorMatrix(new float[][]
                {
                    new float[] {-1, 0, 0, 0, 0},
                    new float[] {0, -1, 0, 0, 0},
                    new float[] {0, 0, -1, 0, 0},
                    new float[] {0, 0, 0, 1, 0},
                    new float[] {1, 1, 1, 0, 1}
                });

                ImageAttributes attributes = new ImageAttributes();
                attributes.SetColorMatrix(invertMatrix);

                g.Clear(Color.Black);
                g.DrawImage(new Bitmap(screenWidth, screenHeight), new Rectangle(0, 0, screenWidth, screenHeight), 0, 0, screenWidth, screenHeight, GraphicsUnit.Pixel, attributes);
            }

            Thread.Sleep(100); // Delay between updates
        }

        ReleaseDC(IntPtr.Zero, desk);
    }

    // Effect 8: Bouncing Message
    private static void RunBouncingMessage()
    {
        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);

        int x = screenWidth / 2;
        int y = screenHeight / 2;
        int velocityX = 5;
        int velocityY = 5;

        IntPtr desk = GetDC(IntPtr.Zero);
        DateTime startTime = DateTime.Now;

        while ((DateTime.Now - startTime).TotalSeconds < 15)
        {
            using (Graphics g = Graphics.FromHdc(desk))
            {
                // Clear the screen
                g.Clear(Color.Black);

                // Draw the bouncing message
                string message = "thatkid101";
                Font font = new Font("Arial", 24);
                Brush brush = new SolidBrush(Color.White);
                g.DrawString(message, font, brush, x, y);

                // Update position of the message
                x += velocityX;
                y += velocityY;

                // Bounce the message off the edges
                if (x <= 0 || x + message.Length * 12 >= screenWidth) velocityX = -velocityX;
                if (y <= 0 || y + 24 >= screenHeight) velocityY = -velocityY;
            }

            Thread.Sleep(16); // ~60 FPS
        }

        ReleaseDC(IntPtr.Zero, desk);
    }
}
