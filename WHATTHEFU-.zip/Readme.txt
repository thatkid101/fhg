WHATTHEFU-.exe

Its safety

Made in : c sharp

RequireMents : No

Skid creds : Pankoza for wave payload and  shader payload

