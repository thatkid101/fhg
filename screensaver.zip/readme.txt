screensaver.py
rate : safe / not safe
type : malware/ joke

you need python and pywin32  and dont press controll alt delete or the malware will stop