pc destroyer.exe 
another malware without a warning
im not responseble for damages made by this trojen
my first gdi trojen