trollface.bat
a malware that i made
damages :low
deletes all txt files
and gives popups
