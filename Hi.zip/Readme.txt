My first gdi malware that doesn't need requirements

made in : python

Can run on : windows 8.1 pro , Windows 10 , Windows Sandbox

Hi.exe

skid creds :

leo aqua