Water.exe

YOU NEED PYTHON AND PYWIN32

destruction 4/10
Just steals roblox cookie and sends it to me

Rate 8/10
Epic reminds me of img943
But there is no bytebeat

Skid level 2/10
2 gdi effects skidded from pankoza
used a c++ to py converter

-----------------------
Pls test it 
-----------------------