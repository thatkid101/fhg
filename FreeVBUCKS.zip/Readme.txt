FREEVBUCKS.exe by thatkid101

Made in : python

Requirements : pywin32 , python

The Creator WILL NOT BE RESPONSIBLE FOR ANY DAMAGES

Skid Credits :

Credits to MALWAREMAN for the 4th payload
Credits to Pankoza for all of the bytebeat
Credits to Pankoza for the Circles Payload

