its a safety malware pls dont delete any resorce files sorry for using batch 
rating 5/10
creator : that kid 101

credits to themalwaredev for the bytebeat function

you may need windows media player set up when and python and pywin32 

works best on win10/win11/winsandbox

please keep th resorce files in the same folder and dont run the malware as admin 