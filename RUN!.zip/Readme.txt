RUN!.exe

Made by : thatkid101

Skid : no just inspiration from pankoza ( the 3rd payload )

Level 5/10

Made in : python

IMPORTANT!!!!!!!!

You must have python and pywin32

The creator will not be held responsible for anything

this malware was made for sum education shit

Notes :

this took me 2 days to make

G.O.A.TS

1. pankoskidder ( pankoza )
2. notmalwarefan
3. thatkid101
4. nazar
5. fr4ctalz
6. CYBER SOILDER
7. Siam Alam



