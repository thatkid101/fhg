Hurricane.exe
my new GDI malware!
made in a few hours
there is no warning because its a waste of time
im not responsable for any damages made by this malware

