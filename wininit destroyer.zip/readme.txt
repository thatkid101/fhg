frick you wininit!
yes look at the code
no skid btw
wininit destroyer!
dameges:low
it kills tskmgr
makes a random vbs file
gives fake error
gives popups that say frick winit
im not responseble for any damages