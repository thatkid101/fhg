this is malware

winlock password is 123

you need python and pywin32

