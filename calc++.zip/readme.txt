calc++
damages:low
it will spam calc a lot
im not responseble  for the damages
run in vm