you shouldnt have done that!
dameges:low
if you run as admin it will kill your tskmgr
im not responseble for the dameges