Needs python and pywin32

any version

by : thatkid101

skid creds : leo aqua

works best on : win 7 - 11

python version : any, only if it has python and pywin32 and pyautogui